<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Business Model Canvas - Ideation</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .form-section {
            background: #f8f9fa;
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 30px;
        }
        .section-title {
            color: #495057;
            font-weight: bold;
            margin-bottom: 20px;
            border-bottom: 3px solid #667eea;
            padding-bottom: 10px;
        }
        .bmc-input {
            border: 2px solid #e9ecef;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 15px;
            transition: all 0.3s ease;
        }
        .bmc-input:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
        }
        .add-item-btn {
            background: linear-gradient(45deg, #667eea, #764ba2);
            border: none;
            color: white;
            padding: 10px 20px;
            border-radius: 25px;
            transition: all 0.3s ease;
        }
        .add-item-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        .remove-item-btn {
            background: #dc3545;
            border: none;
            color: white;
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 0.8rem;
        }
        .submit-btn {
            background: linear-gradient(45deg, #28a745, #20c997);
            border: none;
            color: white;
            padding: 15px 40px;
            border-radius: 50px;
            font-weight: bold;
            font-size: 1.1rem;
        }
        .delete-btn {
            background: linear-gradient(45deg, #dc3545, #e74c3c);
            border: none;
            color: white;
            padding: 10px 25px;
            border-radius: 25px;
            text-decoration: none;
            display: inline-block;
            transition: all 0.3s ease;
        }
        .delete-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            color: white;
        }
        
        /* Responsive Design */
        @media (max-width: 768px) {
            .form-section {
                padding: 20px;
                margin-bottom: 20px;
            }
            
            .section-title {
                font-size: 1.2rem;
                margin-bottom: 15px;
            }
            
            .bmc-input {
                padding: 12px;
                margin-bottom: 12px;
            }
            
            .add-item-btn {
                padding: 8px 16px;
                font-size: 0.9rem;
            }
            
            .remove-item-btn {
                padding: 4px 8px;
                font-size: 0.7rem;
            }
            
            .submit-btn {
                padding: 12px 30px;
                font-size: 1rem;
                width: 100%;
                margin-bottom: 10px;
            }
            
            .delete-btn {
                padding: 8px 20px;
                font-size: 0.9rem;
                width: 100%;
            }
        }
        
        @media (max-width: 576px) {
            .container {
                padding: 0 15px;
            }
            
            .form-section {
                padding: 15px;
                margin-bottom: 15px;
            }
            
            .section-title {
                font-size: 1.1rem;
                margin-bottom: 12px;
            }
            
            .bmc-input {
                padding: 10px;
                margin-bottom: 10px;
            }
            
            .add-item-btn {
                padding: 6px 12px;
                font-size: 0.8rem;
            }
            
            .remove-item-btn {
                padding: 3px 6px;
                font-size: 0.6rem;
            }
            
            .submit-btn {
                padding: 10px 25px;
                font-size: 0.9rem;
            }
            
            .delete-btn {
                padding: 6px 15px;
                font-size: 0.8rem;
            }
        }
    </style>
</head>
<body>
    <div class="container py-5">
        <div class="row">
            <div class="col-lg-8 mx-auto">
                <div class="text-center mb-5">
                    <h1 class="display-5 fw-bold text-primary">Edit Business Model Canvas</h1>
                    <p class="lead">Perbarui informasi bisnis dan BMC Anda</p>
                </div>

                <form action="<?php echo e(route('bmc.update', $business->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    
                    <!-- Business Information Section -->
                    <div class="form-section">
                        <h3 class="section-title">
                            <i class="fas fa-building me-2"></i>Informasi Bisnis
                        </h3>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="owner_name" class="form-label">Nama Pemilik Usaha</label>
                                <input type="text" class="form-control" id="owner_name" name="owner_name" value="<?php echo e($business->owner_name); ?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="business_name" class="form-label">Nama Usaha</label>
                                <input type="text" class="form-control" id="business_name" name="business_name" value="<?php echo e($business->business_name); ?>" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="business_description" class="form-label">Deskripsi Usaha</label>
                            <textarea class="form-control" id="business_description" name="business_description" rows="3" required><?php echo e($business->business_description); ?></textarea>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="location" class="form-label">Lokasi</label>
                                <input type="text" class="form-control" id="location" name="location" value="<?php echo e($business->location); ?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="phone_number" class="form-label">No. Telepon</label>
                                <input type="tel" class="form-control" id="phone_number" name="phone_number" value="<?php echo e($business->phone_number); ?>" required>
                            </div>
                        </div>
                    </div>

                    <!-- BMC Components -->
                    <div class="form-section">
                        <h3 class="section-title">
                            <i class="fas fa-chart-line me-2"></i>Business Model Canvas Components
                        </h3>

                        <!-- Customer Segments -->
                        <div class="mb-4">
                            <label class="form-label fw-bold">1. Customer Segments (Segmen Pelanggan)</label>
                            <p class="text-muted small">Siapa pelanggan target Anda?</p>
                            <div id="customer_segments">
                                <?php $__currentLoopData = $business->bmcData->customer_segments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $segment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="bmc-input">
                                        <input type="text" class="form-control" name="customer_segments[]" value="<?php echo e($segment); ?>" placeholder="Contoh: Orang yang sedang diet">
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <button type="button" class="btn add-item-btn" onclick="addItem('customer_segments')">
                                <i class="fas fa-plus me-1"></i>Tambah Item
                            </button>
                        </div>

                        <!-- Value Propositions -->
                        <div class="mb-4">
                            <label class="form-label fw-bold">2. Value Propositions (Proposisi Nilai)</label>
                            <p class="text-muted small">Nilai unik apa yang Anda tawarkan?</p>
                            <div id="value_propositions">
                                <?php $__currentLoopData = $business->bmcData->value_propositions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="bmc-input">
                                        <input type="text" class="form-control" name="value_propositions[]" value="<?php echo e($value); ?>" placeholder="Contoh: Produk sehat & rendah gula">
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <button type="button" class="btn add-item-btn" onclick="addItem('value_propositions')">
                                <i class="fas fa-plus me-1"></i>Tambah Item
                            </button>
                        </div>

                        <!-- Channels -->
                        <div class="mb-4">
                            <label class="form-label fw-bold">3. Channels (Saluran)</label>
                            <p class="text-muted small">Bagaimana Anda menjangkau pelanggan?</p>
                            <div id="channels">
                                <?php $__currentLoopData = $business->bmcData->channels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $channel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="bmc-input">
                                        <input type="text" class="form-control" name="channels[]" value="<?php echo e($channel); ?>" placeholder="Contoh: Media sosial (Instagram & TikTok)">
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <button type="button" class="btn add-item-btn" onclick="addItem('channels')">
                                <i class="fas fa-plus me-1"></i>Tambah Item
                            </button>
                        </div>

                        <!-- Customer Relationships -->
                        <div class="mb-4">
                            <label class="form-label fw-bold">4. Customer Relationships (Hubungan Pelanggan)</label>
                            <p class="text-muted small">Jenis hubungan apa yang Anda bangun?</p>
                            <div id="customer_relationships">
                                <?php $__currentLoopData = $business->bmcData->customer_relationships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relationship): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="bmc-input">
                                        <input type="text" class="form-control" name="customer_relationships[]" value="<?php echo e($relationship); ?>" placeholder="Contoh: Layanan personal untuk custom order">
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <button type="button" class="btn add-item-btn" onclick="addItem('customer_relationships')">
                                <i class="fas fa-plus me-1"></i>Tambah Item
                            </button>
                        </div>

                        <!-- Revenue Streams -->
                        <div class="mb-4">
                            <label class="form-label fw-bold">5. Revenue Streams (Arus Pendapatan)</label>
                            <p class="text-muted small">Bagaimana bisnis Anda menghasilkan uang?</p>
                            <div id="revenue_streams">
                                <?php $__currentLoopData = $business->bmcData->revenue_streams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $revenue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="bmc-input">
                                        <input type="text" class="form-control" name="revenue_streams[]" value="<?php echo e($revenue); ?>" placeholder="Contoh: Penjualan langsung ke konsumen">
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <button type="button" class="btn add-item-btn" onclick="addItem('revenue_streams')">
                                <i class="fas fa-plus me-1"></i>Tambah Item
                            </button>
                        </div>

                        <!-- Key Resources -->
                        <div class="mb-4">
                            <label class="form-label fw-bold">6. Key Resources (Sumber Daya Utama)</label>
                            <p class="text-muted small">Sumber daya apa yang dibutuhkan?</p>
                            <div id="key_resources">
                                <?php $__currentLoopData = $business->bmcData->key_resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resource): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="bmc-input">
                                        <input type="text" class="form-control" name="key_resources[]" value="<?php echo e($resource); ?>" placeholder="Contoh: Dapur produksi & alat baking premium">
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <button type="button" class="btn add-item-btn" onclick="addItem('key_resources')">
                                <i class="fas fa-plus me-1"></i>Tambah Item
                            </button>
                        </div>

                        <!-- Key Activities -->
                        <div class="mb-4">
                            <label class="form-label fw-bold">7. Key Activities (Aktivitas Utama)</label>
                            <p class="text-muted small">Aktivitas apa yang harus dilakukan?</p>
                            <div id="key_activities">
                                <?php $__currentLoopData = $business->bmcData->key_activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="bmc-input">
                                        <input type="text" class="form-control" name="key_activities[]" value="<?php echo e($activity); ?>" placeholder="Contoh: Produksi macaron rendah gula">
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <button type="button" class="btn add-item-btn" onclick="addItem('key_activities')">
                                <i class="fas fa-plus me-1"></i>Tambah Item
                            </button>
                        </div>

                        <!-- Key Partnerships -->
                        <div class="mb-4">
                            <label class="form-label fw-bold">8. Key Partnerships (Kemitraan Utama)</label>
                            <p class="text-muted small">Siapa mitra strategis Anda?</p>
                            <div id="key_partnerships">
                                <?php $__currentLoopData = $business->bmcData->key_partnerships; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partnership): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="bmc-input">
                                        <input type="text" class="form-control" name="key_partnerships[]" value="<?php echo e($partnership); ?>" placeholder="Contoh: Supplier bahan baku">
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <button type="button" class="btn add-item-btn" onclick="addItem('key_partnerships')">
                                <i class="fas fa-plus me-1"></i>Tambah Item
                            </button>
                        </div>

                        <!-- Cost Structure -->
                        <div class="mb-4">
                            <label class="form-label fw-bold">9. Cost Structure (Struktur Biaya)</label>
                            <p class="text-muted small">Biaya apa saja yang diperlukan?</p>
                            <div id="cost_structure">
                                <?php $__currentLoopData = $business->bmcData->cost_structure; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="bmc-input">
                                        <input type="text" class="form-control" name="cost_structure[]" value="<?php echo e($cost); ?>" placeholder="Contoh: Biaya bahan baku premium">
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <button type="button" class="btn add-item-btn" onclick="addItem('cost_structure')">
                                <i class="fas fa-plus me-1"></i>Tambah Item
                            </button>
                        </div>
                    </div>

                    <div class="text-center">
                        <button type="submit" class="btn submit-btn me-3">
                            <i class="fas fa-save me-2"></i>Perbarui BMC
                        </button>
                        <a href="<?php echo e(route('bmc.show', $business->id)); ?>" class="btn btn-outline-secondary me-3">
                            <i class="fas fa-eye me-2"></i>Lihat BMC
                        </a>
                        <a href="#" class="delete-btn" onclick="confirmDelete()">
                            <i class="fas fa-trash me-2"></i>Hapus BMC
                        </a>
                    </div>
                </form>

                <!-- Delete Form -->
                <form id="delete-form" action="<?php echo e(route('bmc.destroy', $business->id)); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                </form>
            </div>
        </div>
    </div>

    <script>
        function addItem(containerId) {
            const container = document.getElementById(containerId);
            const newItem = document.createElement('div');
            newItem.className = 'bmc-input';
            newItem.innerHTML = `
                <div class="d-flex">
                    <input type="text" class="form-control me-2" name="${containerId}[]" placeholder="Masukkan item baru">
                    <button type="button" class="btn remove-item-btn" onclick="removeItem(this)">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            `;
            container.appendChild(newItem);
        }

        function removeItem(button) {
            button.closest('.bmc-input').remove();
        }

        function confirmDelete() {
            if (confirm('Apakah Anda yakin ingin menghapus BMC ini? Tindakan ini tidak dapat dibatalkan.')) {
                document.getElementById('delete-form').submit();
            }
        }
    </script>
</body>
</html>
<?php /**PATH D:\Magang\StartUp Ideation\resources\views\bmc\edit.blade.php ENDPATH**/ ?>